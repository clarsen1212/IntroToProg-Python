#-------------------------------------------------#
# Title: Assignment 06 - Functions
# Dev:   RRoot
# Date:  July 16, 2012
# ChangeLog: (Who, When, What)
#   CLarsen, 11/10/2016, Used this code as a starting point to complete Assignment 06
#-------------------------------------------------#

#-- Data --#
# declare variables and constants
# objFile = An object that represents a file
# strData = A row of text data from the file
# dicRow = A row of data separated into elements of a dictionary {Task,Priority}
# lstTable = A dictionary that acts as a 'table' of rows
# strMenu = A menu of user options
# strChoice = Capture the user option selection

#-- Input/Output --#
# User can see a Menu (Step 2)
# User can see data (Step 3)
# User can insert or delete data(Step 4 and 5)
# User can save to file (Step 6)

#-- Processing --#
# Step 1
# When the program starts, load any data you have
# into a text file called ToDo.txt into a python Dictionary.

# Step 2
# Display a menu of choices to the user

# Step 3
# Display all todo items to user

# Step 4
# Add a new item to the list/Table

# Step 5
# Remove a new item to the list/Table

# Step 6
# Save tasks to the ToDo.txt file

# Step 7
# Exit program
#-------------------------------

objFileName = "Todo.txt"
strData = ""
dicRow = {}
lstTable = []

# Step 1
# When the program starts, load the any data you have
# in a text file called ToDo.txt into a python Dictionary.
def DataInput():
    '''
    The purpose of this function is to load data from ToDo.txt into a dictionary format
    :return:
    '''
    objFile = open(objFileName, "r")
    for line in objFile:
        strData = line.split(",") # readline() reads a line of the data into 2 elements
        dicRow = {"Task": strData[0].strip(), "Priority": strData[0].strip()}
        lstTable.append(dicRow)
    objFile.close()
# Step 2
#Show the user the main menu
def MenuSelection():
    '''
    The purpose of this function is to show the user a menu and prompt them for an input
    :return:
    '''
    print("""
        Menu of Options
        1) Show current data
        2) Add a new item.
        3) Remove an existing item.
        4) Save Data to File
        5) Exit Program
        """)
    strChoice = str(input("Which option would you like to perform? [1 to 4] - "))
    print()  # adding a new line
    return strChoice
#Step 3
#Allow the user to view existing data
def DisplayExistingData():
    '''
    The user may can view the data that is currently being stored
    :return:???

    '''
    # Show the current items in the table

        print("******* The current items ToDo are: *******")
        for row in lstTable:
            print(row["Task"] + "(" + row["Priority"] + ")")
        print("*******************************************")
#Step 4
#Allow the user to add a new task to the table
def AddNew():
    '''
    This will allow the user to add a new task and its priority
    :return:
    '''
    strTask = str(input("What is the task? - ")).strip()
                strPriority = str(input("What is the priority? [high|low] - ")).strip()
                dicRow = {"Task":strTask,"Priority":strPriority}
                lstTable.append(dicRow)
                print("Current Data in table:")
                for dicRow in lstTable:
                    print(dicRow)
#Step 5
#Remove an item from the table
def DeleteItem():
    '''
    This will allow the user to indicate an item to delete
    in the current list of data
    :return:
    '''
    # 5a-Allow user to indicate which row to delete
    strKeyToRemove = input("Which TASK would you like removed? - ")
    blnItemRemoved = False  # Creating a boolean Flag
    intRowNumber = 0
    while (intRowNumber < len(lstTable)):
        if (strKeyToRemove == str(list(dict(lstTable[intRowNumber]).values())[1])):  # the values function creates a list!
            del lstTable[intRowNumber]
            blnItemRemoved = True
        # end if
        intRowNumber += 1
    # end for loop
    # 5b-Update user on the status
    if (blnItemRemoved == True):
        print("The task was removed.")
    else:
        print("I'm sorry, but I could not find that task.")
#Step 6
#Allow the user to save the data to ToDo.txt
def SaveFile():
    '''
    This asks the user whether they would like to save the existing
    list of task data
    :return:
    '''
    objFile = open(objFileName, "w")
    for dicRow in lstTable:
        objFile.write(dicRow["Task"] + "," + dicRow["Priority"] + "\n")
    objFile.close()
    input("Data saved to file! Press the [Enter] key to return to menu.")

'''
%%%%%%%%%%%%%%%%%%%%%%%    MAIN SECTION   %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
'''
#This section is where all the functions will be called
#Step 1 - Calls the function in the Step 1 section above
DataInput()
#Step 2 - Calls the function in the Step 2 section above
while(True):
    # Step 2
    # Display a menu of choices to the user
    strChoice = MenuSelection()
    #Step 3
    if (strChoice.strip() == '1'):
    DisplayExistingData()
    #Step 4
    elif (strChoice.strip() == '2'):
    AddNew()
    DisplayExistingData()
    #Step 5
    elif (strChoice == '3'):
    DeleteItem()
    DisplayExistingData()
    #Step 6
    elif(strChoice == '4'):
    DisplayExistingData()
    if ("y" == str(input("Save this data to file? (y/n) - ")).strip().lower()):
         SaveFile()
    else:
        input("New data was NOT Saved, but previous data still exists! Press the [Enter] key to return to menu.")
    continue  # to show the menu
    #Final Step
    elif (strChoice == '5'):
    break  # and Exit the program
'''
%%%%%%%%%%%%%%%%%%%%%%%   MAIN SECTION   %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
'''


