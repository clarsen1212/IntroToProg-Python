'''---------------------------------------------------
Title: Module 05 Final Assignment
Dev: CLarsen
Date: November 5th, 2016
Desc: The purpose of this script is to store data in a dictionary format
Changelog: (Who, When, What)

---------------------------------------------------'''


#Add code to read two rows of To-Do list data from a txt file and store into a dictionary
objfile = open("ToDo.txt", "r")
ToDo = {}
for line in objfile:
    items = line.split(",")
    ToDo = {}
    ToDo['Task'] = items[0]
    ToDo['Priority'] = items[1]
    print (ToDo)
objfile.close()
#store the new dictionary rows into a list
lstToDo = []
for row in ToDo:
    lstToDo.append(ToDo)
#show the user what the stored data looks like
print (lstToDo)

#Use a while loop to prompt the user to choose one of the following:
#1 Add Task
#2 Remove Task
#3 Save Tasks to a file and exit
while (True):
    print ("Please do one of the following:")
    print ("Enter 1 to add a new task")
    print ("Enter 2 to delete a task")
    print ("Enter 3 to save all tasks to the ToDo.txt file and exit")

    intinput = input(str("Please type your selection:"))
    if intinput == "1":
        Task3 = input(str("Please type a new task:"))
        Priority3 = input(str("Please type the priority of this task:"))
        dictrow3 = {'Task':Task3, "Priority":Priority3}
        lstToDo.append(dictrow3)
        print(lstToDo)
    elif intinput == "2":
        print (lstToDo)
        itemremove = input(str("Which item would you like to remove? (choose a number):"))
        del lstToDo [itemremove]
    elif intinput == "3":
        objfile == open("ToDo.txt", "w")
        print ("The following data has now been saved:")
        print (lstToDo)
        objfile.write(str(lstToDo))
    objfile.close()
    if (input("Type 'exit' to end. Type anything else to continue: ") == "exit"): break
